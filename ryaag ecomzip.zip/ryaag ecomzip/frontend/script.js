let currentUser = null;
let cart = JSON.parse(localStorage.getItem('guestCart')) || [];
let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];
let recentlyViewed = JSON.parse(localStorage.getItem('recentlyViewed')) || [];
let loyaltyPoints = parseInt(localStorage.getItem('loyaltyPoints')) || 0;
let token = null;
const BASE_URL = 'https://your-app-name.herokuapp.com'; // Replace with your deployed backend URL

// Initialize page
document.addEventListener('DOMContentLoaded', async function() {
    await loadContent();
    loadUserState();
    updateCart();
    await renderProducts();
    await renderCategories();
    renderRecentlyViewed();
    if (currentUser && currentUser.isAdmin) {
        await renderAdminPanel();
        setupAdminTabs();
    } else if (currentUser) {
        renderWishlist();
    }
    trackPageView();
    applyTheme(localStorage.getItem('theme') || 'light');
    setupChatbot();
});

// API Fetch Helper
async function apiFetch(url, options = {}) {
    options.headers = {
        ...options.headers,
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    };
    const response = await fetch(`${BASE_URL}${url}`, options);
    if (!response.ok) throw new Error(await response.text());
    return response.json();
}

// Content Management
async function loadContent() {
    const content = await apiFetch('/api/content');
    document.getElementById('site-title').textContent = content.siteTitle;
    document.getElementById('home-title').textContent = content.homeTitle;
    document.getElementById('home-content').innerHTML = content.homeContent;
    const contactEmailLink = document.getElementById('contact-email-link');
    contactEmailLink.textContent = content.contactEmail;
    contactEmailLink.href = `mailto:${content.contactEmail}`;
}

// User Account Functions
function loadUserState() {
    const userStatus = document.getElementById('user-status');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const accountDetails = document.getElementById('account-details');
    const currentUserSpan = document.getElementById('current-user');
    const loyaltyPointsSpan = document.getElementById('loyalty-points');
    const adminLink = document.getElementById('admin-link');
    const adminSection = document.getElementById('admin');
    const ordersLink = document.getElementById('orders-link');
    const wishlistLink = document.getElementById('wishlist-link');

    if (currentUser) {
        userStatus.textContent = `Welcome, ${currentUser.username}, to RYAAG's radiant circle.`;
        loginForm.style.display = 'none';
        registerForm.style.display = 'none';
        accountDetails.style.display = 'block';
        currentUserSpan.textContent = currentUser.username;
        loyaltyPointsSpan.textContent = currentUser.loyaltyPoints || loyaltyPoints;
        adminLink.style.display = currentUser.isAdmin ? 'block' : 'none';
        adminSection.style.display = currentUser.isAdmin ? 'block' : 'none';
        ordersLink.style.display = 'block';
        wishlistLink.style.display = 'block';
        renderOrders();
        renderWishlist();
    } else {
        userStatus.textContent = 'Welcome, radiant beauty.';
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
        accountDetails.style.display = 'none';
        adminLink.style.display = 'none';
        adminSection.style.display = 'none';
        ordersLink.style.display = 'none';
        wishlistLink.style.display = 'none';
    }
}

document.getElementById('register-btn').addEventListener('click', async function() {
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;
    try {
        const data = await apiFetch('/api/auth/register', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
        token = data.token;
        alert('Welcome to RYAAG’s radiant circle! Please login to indulge.');
        toggleForms();
    } catch (err) {
        alert(err.message);
    }
});

document.getElementById('login-btn').addEventListener('click', async function() {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    try {
        const data = await apiFetch('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
        token = data.token;
        currentUser = { 
            username: data.username, 
            isAdmin: data.isAdmin, 
            id: data.id, 
            loyaltyPoints: data.loyaltyPoints || 0 
        };
        cart = data.cart || [];
        wishlist = data.wishlist || [];
        localStorage.removeItem('guestCart');
        localStorage.setItem('wishlist', JSON.stringify(wishlist));
        localStorage.setItem('loyaltyPoints', currentUser.loyaltyPoints);
        loadUserState();
        updateCart();
        if (currentUser.isAdmin) {
            await renderAdminPanel();
            setupAdminTabs();
        }
    } catch (err) {
        alert(err.message);
    }
});

document.getElementById('logout-btn').addEventListener('click', function() {
    currentUser = null;
    cart = [];
    wishlist = [];
    loyaltyPoints = 0;
    token = null;
    localStorage.removeItem('guestCart');
    localStorage.removeItem('wishlist');
    localStorage.removeItem('loyaltyPoints');
    loadUserState();
    updateCart();
});

function toggleForms() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    loginForm.style.display = loginForm.style.display === 'none' ? 'block' : 'none';
    registerForm.style.display = registerForm.style.display === 'none' ? 'block' : 'none';
}

// Cart Functions
document.addEventListener('click', async function(e) {
    if (e.target.classList.contains('add-to-cart')) {
        const name = e.target.getAttribute('data-name');
        const price = parseFloat(e.target.getAttribute('data-price'));
        const variant = e.target.previousElementSibling?.value || 'Default';
        const item = { name, price, variant };
        cart.push(item);
        if (currentUser) {
            await apiFetch(`/api/users/${currentUser.id}`, {
                method: 'PUT',
                body: JSON.stringify({ cart, wishlist, loyaltyPoints: currentUser.loyaltyPoints })
            });
        } else {
            localStorage.setItem('guestCart', JSON.stringify(cart));
        }
        updateCart();
        gtag('event', 'add_to_cart', { items: [{ name, price, variant }] });
    } else if (e.target.classList.contains('add-to-wishlist')) {
        const name = e.target.getAttribute('data-name');
        const price = parseFloat(e.target.getAttribute('data-price'));
        const item = { name, price };
        if (!wishlist.some(w => w.name === name)) {
            wishlist.push(item);
            if (currentUser) {
                await apiFetch(`/api/users/${currentUser.id}`, {
                    method: 'PUT',
                    body: JSON.stringify({ cart, wishlist, loyaltyPoints: currentUser.loyaltyPoints })
                });
            }
            localStorage.setItem('wishlist', JSON.stringify(wishlist));
            renderWishlist();
            alert(`${name} added to your luxe wishlist!`);
        }
    } else if (e.target.classList.contains('submit-review')) {
        const productId = e.target.getAttribute('data-product-id');
        const rating = prompt('Rate this luxury item (1-5):');
        const comment = prompt('Share your glamorous thoughts:');
        if (rating && comment) {
            await apiFetch('/api/reviews', {
                method: 'POST',
                body: JSON.stringify({ productId, rating, comment, user: currentUser?.username || 'Guest' })
            });
            renderProducts();
        }
    }
});

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    const cartCount = document.getElementById('cart-count');
    const cartSubtotal = document.getElementById('cart-subtotal');
    const cartTotal = document.getElementById('cart-total');
    let discount = 0;

    cartItems.innerHTML = '';
    cart.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.name} (${item.variant}) - $${item.price.toFixed(2)}`;
        cartItems.appendChild(li);
    });

    cartCount.textContent = cart.length;
    const subtotal = cart.reduce((sum, item) => sum + item.price, 0);
    cartSubtotal.textContent = subtotal.toFixed(2);
    const discountCode = document.getElementById('discount-code').value;
    if (discountCode) {
        try {
            const promo = await apiFetch(`/api/promotions/${discountCode}`);
            if (promo) discount = subtotal * (promo.discount / 100);
        } catch (err) {
            console.log('No valid promo code');
        }
    }
    cartTotal.textContent = (subtotal - discount).toFixed(2);
}

document.getElementById('apply-discount').addEventListener('click', async () => {
    await updateCart();
});

async function checkout(isGuest = false) {
    if (cart.length === 0) {
        alert('Your luxe cart is empty!');
        return;
    }
    const total = parseFloat(document.getElementById('cart-total').textContent);
    const paymentMethod = document.getElementById('payment-method').value;
    const order = { items: cart, total, status: 'Pending', paymentMethod };

    try {
        let response;
        if (currentUser) {
            order.userId = currentUser.id;
            response = await apiFetch('/api/orders', {
                method: 'POST',
                body: JSON.stringify(order)
            });
            currentUser.loyaltyPoints = (currentUser.loyaltyPoints || 0) + Math.floor(total / 10);
            await apiFetch(`/api/users/${currentUser.id}`, {
                method: 'PUT',
                body: JSON.stringify({ cart, wishlist, loyaltyPoints: currentUser.loyaltyPoints })
            });
            localStorage.setItem('loyaltyPoints', currentUser.loyaltyPoints);
            document.getElementById('loyalty-points').textContent = currentUser.loyaltyPoints;
        } else if (isGuest) {
            response = await apiFetch('/api/orders/guest', {
                method: 'POST',
                body: JSON.stringify(order)
            });
        } else {
            alert('Please login or proceed as a guest to indulge!');
            return;
        }
        processPayment(paymentMethod, response.paymentIntent);
        alert(`Thank you for your glamorous purchase! Total: $${total.toFixed(2)} via ${paymentMethod}`);
        gtag('event', 'purchase', { transaction_id: response._id, value: total, currency: 'USD', items: cart });
        cart = [];
        if (currentUser) {
            await apiFetch(`/api/users/${currentUser.id}`, { method: 'PUT', body: JSON.stringify({ cart, wishlist, loyaltyPoints: currentUser.loyaltyPoints }) });
        } else {
            localStorage.removeItem('guestCart');
        }
        updateCart();
        if (currentUser) renderOrders();
    } catch (err) {
        alert(`Payment failed: ${err.message}`);
    }
}

function processPayment(method, paymentIntent) {
    switch (method) {
        case 'stripe':
            console.log(`Processing Stripe payment: ${paymentIntent}`);
            break;
        case 'paypal':
            console.log(`Processing PayPal payment: ${paymentIntent}`);
            break;
        case 'square':
            console.log(`Processing Square payment: ${paymentIntent}`);
            break;
        default:
            throw new Error('Unsupported payment method');
    }
}

document.getElementById('checkout').addEventListener('click', () => checkout(false));
document.getElementById('guest-checkout').addEventListener('click', () => checkout(true));
document.getElementById('shop-now').addEventListener('click', () => window.location.hash = '#products');

// Product and Category Management
async function renderProducts(category = 'all') {
    const products = await apiFetch('/api/products');
    const reviews = await apiFetch('/api/reviews');
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';
    const filteredProducts = category === 'all' ? products : products.filter(p => p.category === category);
    filteredProducts.forEach(product => {
        const div = document.createElement('div');
        div.className = 'product';
        const variants = product.variants ? product.variants.split(',') : ['Default'];
        const variantOptions = variants.map(v => `<option value="${v}">${v}</option>`).join('');
        const swatches = product.swatches ? product.swatches.split(',').map(s => `<div class="swatch" style="background-color: ${s.trim()};"></div>`).join('') : '';
        const productReviews = reviews.filter(r => r.productId === product._id.toString());
        const reviewList = productReviews.slice(0, 1).map(r => `<p>${r.rating}/5 - ${r.comment} by ${r.user}</p>`).join('');
        const isBestSeller = product.sales > 10; // Arbitrary threshold
        recentlyViewed = recentlyViewed.filter(p => p.name !== product.name).slice(0, 4);
        recentlyViewed.unshift({ name: product.name, price: product.price });
        localStorage.setItem('recentlyViewed', JSON.stringify(recentlyViewed));
        div.innerHTML = `
            ${isBestSeller ? '<span class="best-seller">Best Seller</span>' : ''}
            <h3>${product.name}</h3>
            <p>$${product.price.toFixed(2)}</p>
            <small>Category: ${product.category}</small><br>
            <div class="swatches">${swatches}</div>
            <select>${variantOptions}</select>
            <button class="add-to-cart" data-name="${product.name}" data-price="${product.price}">Add to Cart</button>
            <button class="add-to-wishlist" data-name="${product.name}" data-price="${product.price}">Wishlist</button>
            <div class="reviews">${reviewList}<button class="submit-review" data-product-id="${product._id}">Add Review</button></div>
        `;
        productList.appendChild(div);
    });
    renderRecentlyViewed();
}

async function renderCategories() {
    const categories = await apiFetch('/api/categories');
    const categoryFilter = document.getElementById('category-filter');
    const productCategory = document.getElementById('product-category');
    categoryFilter.innerHTML = '<option value="all">All Luxe Categories</option>';
    productCategory.innerHTML = '';
    categories.forEach(category => {
        const optionFilter = document.createElement('option');
        optionFilter.value = category;
        optionFilter.textContent = category;
        categoryFilter.appendChild(optionFilter);

        const optionProduct = document.createElement('option');
        optionProduct.value = category;
        optionProduct.textContent = category;
        productCategory.appendChild(optionProduct);
    });

    categoryFilter.addEventListener('change', function() {
        renderProducts(this.value);
    });
}

async function renderOrders() {
    if (!currentUser) return;
    const orders = await apiFetch(`/api/orders/user/${currentUser.id}`);
    const orderList = document.getElementById('order-list');
    orderList.innerHTML = '';
    orders.forEach(order => {
        const li = document.createElement('li');
        li.textContent = `Order #${order._id} - $${order.total.toFixed(2)} - Status: ${order.status} (Paid via ${order.paymentMethod})`;
        orderList.appendChild(li);
    });
}

async function renderWishlist() {
    const wishlistItems = document.getElementById('wishlist-items');
    wishlistItems.innerHTML = '';
    wishlist.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - $${item.price.toFixed(2)}`;
        wishlistItems.appendChild(li);
    });
}

function renderRecentlyViewed() {
    const recentlyViewedItems = document.getElementById('recently-viewed-items');
    recentlyViewedItems.innerHTML = '';
    recentlyViewed.forEach(item => {
        const div = document.createElement('div');
        div.className = 'product';
        div.innerHTML = `
            <h3>${item.name}</h3>
            <p>$${item.price.toFixed(2)}</p>
            <button class="add-to-cart" data-name="${item.name}" data-price="${item.price}">Add to Cart</button>
        `;
        recentlyViewedItems.appendChild(div);
    });
}

async function renderGiftFinder() {
    const budget = parseFloat(document.getElementById('gift-budget').value) || Infinity;
    const occasion = document.getElementById('gift-occasion').value;
    const products = await apiFetch('/api/products');
    const giftResults = document.getElementById('gift-results');
    giftResults.innerHTML = '';
    const filteredProducts = products.filter(p => p.price <= budget && (occasion === 'self-care' || p.category !== 'Undergarments'));
    filteredProducts.slice(0, 4).forEach(product => {
        const div = document.createElement('div');
        div.className = 'product';
        const variants = product.variants ? product.variants.split(',') : ['Default'];
        const variantOptions = variants.map(v => `<option value="${v}">${v}</option>`).join('');
        div.innerHTML = `
            <h3>${product.name}</h3>
            <p>$${product.price.toFixed(2)}</p>
            <select>${variantOptions}</select>
            <button class="add-to-cart" data-name="${product.name}" data-price="${product.price}">Add to Cart</button>
        `;
        giftResults.appendChild(div);
    });
}

document.getElementById('find-gift').addEventListener('click', renderGiftFinder);

async function renderAdminPanel() {
    const products = await apiFetch('/api/products');
    const categories = await apiFetch('/api/categories');
    const users = await apiFetch('/api/users');
    const orders = await apiFetch('/api/orders');
    const analytics = await apiFetch('/api/analytics');
    const promotions = await apiFetch('/api/promotions');
    const content = await apiFetch('/api/content');

    document.getElementById('page-views').textContent = analytics.pageViews;
    document.getElementById('total-sales').textContent = analytics.totalSales.toFixed(2);
    document.getElementById('active-users').textContent = users.length;
    document.getElementById('pending-orders').textContent = orders.filter(o => o.status === 'Pending').length;

    const adminProductList = document.getElementById('admin-product-list');
    adminProductList.innerHTML = '';
    products.forEach(product => {
        const li = document.createElement('li');
        li.innerHTML = `${product.name} - $${product.price.toFixed(2)} (${product.category}, Variants: ${product.variants || 'None'}, Swatches: ${product.swatches || 'None'}, Stock: ${product.stock || 0}, Sales: ${product.sales || 0}) <button class="remove-btn" data-type="product" data-id="${product._id}">Remove</button>`;
        adminProductList.appendChild(li);
    });

    const adminCategoryList = document.getElementById('admin-category-list');
    adminCategoryList.innerHTML = '';
    categories.forEach(category => {
        const li = document.createElement('li');
        li.innerHTML = `${category} <button class="edit-btn" data-type="category" data-name="${category}">Edit</button> <button class="remove-btn" data-type="category" data-name="${category}">Remove</button>`;
        adminCategoryList.appendChild(li);
    });

    const adminOrderList = document.getElementById('admin-order-list');
    adminOrderList.innerHTML = '';
    orders.forEach(order => {
        const li = document.createElement('li');
        li.innerHTML = `Order #${order.