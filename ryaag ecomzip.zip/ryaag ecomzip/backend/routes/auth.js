const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    try {
        let user = await User.findOne({ username });
        if (user) return res.status(400).json({ message: 'Username already exists' });

        user = new User({ username, password: await bcrypt.hash(password, 10) });
        await user.save();

        const token = jwt.sign({ id: user._id, isAdmin: user.isAdmin }, 'secret', { expiresIn: '1h' });
        res.json({ token });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ username });
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(400).json({ message: 'Invalid credentials' });
        }

        const token = jwt.sign({ id: user._id, isAdmin: user.isAdmin }, 'secret', { expiresIn: '1h' });
        res.json({ token, username: user.username, isAdmin: user.isAdmin, cart: user.cart, wishlist: user.wishlist, id: user._id, loyaltyPoints: user.loyaltyPoints });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;