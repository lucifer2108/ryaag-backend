const express = require('express');
const router = express.Router();
const Analytics = require('../models/Analytics');
const auth = require('../middleware/auth');

router.get('/', auth, async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: 'Admin access required' });
    let analytics = await Analytics.findOne();
    if (!analytics) analytics = new Analytics();
    res.json(analytics);
});

router.post('/view', async (req, res) => {
    let analytics = await Analytics.findOne();
    if (!analytics) analytics = new Analytics();
    analytics.pageViews += 1;
    await analytics.save();
    res.json({ message: 'Page view tracked' });
});

router.post('/cart', async (req, res) => {
    let analytics = await Analytics.findOne();
    if (!analytics) analytics = new Analytics();
    analytics.cartAdds += 1;
    await analytics.save();
    res.json({ message: 'Cart add tracked' });
});

module.exports = router;