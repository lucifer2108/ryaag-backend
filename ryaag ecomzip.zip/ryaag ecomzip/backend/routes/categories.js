const express = require('express');
const router = express.Router();
const Category = require('../models/Category');
const Product = require('../models/Product');
const auth = require('../middleware/auth');

router.get('/', async (req, res) => {
    const categories = await Category.find();
    res.json(categories.map(c => c.name));
});

router.post('/', auth, async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: 'Admin access required' });
    const { name } = req.body;
    try {
        const category = new Category({ name });
        await category.save();
        res.json(category);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.put('/:id', auth, async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: 'Admin access required' });
    const { name } = req.body;
    try {
        const category = await Category.findById(req.params.id);
        const oldName = category.name;
        category.name = name;
        await category.save();
        await Product.updateMany({ category: oldName }, { category: name });
        res.json(category);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.delete('/:id', auth, async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: 'Admin access required' });
    const category = await Category.findById(req.params.id);
    if (await Product.findOne({ category: category.name })) {
        return res.status(400).json({ message: 'Cannot delete category with assigned products' });
    }
    await Category.findByIdAndDelete(req.params.id);
    res.json({ message: 'Category deleted' });
});

module.exports = router;