const express = require('express');
const router = express.Router();
const Content = require('../models/Content');
const auth = require('../middleware/auth');

router.get('/', async (req, res) => {
    let content = await Content.findOne();
    if (!content) {
        content = new Content();
        await content.save();
    }
    res.json(content);
});

router.put('/', auth, async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: 'Admin access required' });
    const updates = req.body;
    let content = await Content.findOne();
    if (!content) content = new Content();
    Object.assign(content, updates);
    await content.save();
    res.json(content);
});

module.exports = router;