const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');
const auth = require('../middleware/auth');
const Analytics = require('../models/Analytics');

router.get('/', auth, async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: 'Admin access required' });
    const orders = await Order.find();
    res.json(orders);
});

router.get('/user/:userId', auth, async (req, res) => {
    if (req.user.id !== req.params.userId) return res.status(403).json({ message: 'Access denied' });
    const orders = await Order.find({ userId: req.params.userId });
    res.json(orders);
});

router.post('/', auth, async (req, res) => {
    const { items, total, paymentMethod } = req.body;
    try {
        const order = new Order({ userId: req.user.id, items, total, paymentMethod });
        await order.save();
        let analytics = await Analytics.findOne();
        if (!analytics) analytics = new Analytics();
        analytics.totalSales += total;
        await analytics.save();
        for (const item of items) {
            await Product.findOneAndUpdate({ name: item.name }, { $inc: { sales: 1 } });
        }
        const paymentIntent = `pi_${order._id}_${paymentMethod}`;
        res.json({ ...order.toObject(), paymentIntent });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.post('/guest', async (req, res) => {
    const { items, total, paymentMethod } = req.body;
    try {
        const order = new Order({ items, total, paymentMethod });
        await order.save();
        let analytics = await Analytics.findOne();
        if (!analytics) analytics = new Analytics();
        analytics.totalSales += total;
        await analytics.save();
        for (const item of items) {
            await Product.findOneAndUpdate({ name: item.name }, { $inc: { sales: 1 } });
        }
        const paymentIntent = `pi_${order._id}_${paymentMethod}`;
        res.json({ ...order.toObject(), paymentIntent });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.put('/:id', auth, async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: 'Admin access required' });
    const { status } = req.body;
    try {
        const order = await Order.findById(req.params.id);
        order.status = status;
        await order.save();
        res.json(order);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;