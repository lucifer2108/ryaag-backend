const express = require('express');
const router = express.Router();
const Promotion = require('../models/Promotion');
const auth = require('../middleware/auth');

router.get('/', auth, async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: 'Admin access required' });
    const promotions = await Promotion.find();
    res.json(promotions);
});

router.get('/:code', async (req, res) => {
    const promo = await Promotion.findOne({ code: req.params.code });
    if (!promo) return res.status(404).json({ message: 'Promotion not found' });
    res.json(promo);
});

router.post('/', auth, async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: 'Admin access required' });
    const { code, discount } = req.body;
    try {
        const promotion = new Promotion({ code, discount });
        await promotion.save();
        res.json(promotion);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.delete('/:id', auth, async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: 'Admin access required' });
    await Promotion.findByIdAndDelete(req.params.id);
    res.json({ message: 'Promotion deleted' });
});

module.exports = router;